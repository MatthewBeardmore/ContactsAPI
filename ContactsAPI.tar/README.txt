To run our script, simply execute ./contacts.sh; there are no command line
parameters.

If you want to use a test Google account that is already pre-populated with
example contacts data, use the following Google account credentials:

 Username: contactsapitestuser@gmail.com
 Password: passwordPassword
